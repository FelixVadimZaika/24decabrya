create database AcademyHomeWork
go
use AcademyHomeWork
go
create table Teachers
(
  Id int not null primary key identity (1,1),
    Name nvarchar(max) not null check(Name <> ''),
    Surname nvarchar(max) not null check(Surname <> '')
);
go
insert into Teachers(Name,Surname)
values   ('Jeck','Grgg'),
         ('Tom','Slutski'),
		 ('Nazar','Zagoski'),
		 ('Oleg','Boicko');
		 go

create table Assistents
(
   Id int not null primary key identity (1,1),
   TeachersId int not null references Teachers(Id)

);
go
insert into Assistents(TeachersId)
values  (1),
        (2),
		(3),
		(4);
		go

create table Deans
(
   Id int not null primary key identity (1,1),
   TeachersId int not null references Teachers(Id)

);
go
insert into Deans(TeachersId)
values  (3),
        (4),
		(1),
		(2);
		go

create table Curators
(
   Id int not null primary key identity (1,1),
   TeachersId int not null references Teachers(Id)

);
go
insert into Curators(TeachersId)
values  (2),
        (3),
		(2),
		(1);
		go

create table Subjects
(
   Id int not null primary key identity (1,1),
   Name nvarchar(max) not null check(Name<>'') 
);
go
insert into Subjects(Name)
values  ('Biology'),
        ('MAthematic'),
		('Literature'),
		('Geographic');
		go

create table Lectures 
(
   Id int not null primary key identity (1,1),
   SubjectId int not null references Subjects(Id),
   TEacherId int not null references Teachers(Id)
);
go
insert into Lectures(SubjectId,TEacherId)
values  (1,2),
        (4,2),
		(2,1),
		(3,2);
		go
create table Faculties
(
  Id int not null primary key identity (1,1),
  Bilding nvarchar(max) not null check(Bilding <>''),
  Name nvarchar(max) not null check(Name <>''),
  DeanId int not null references Deans(Id)
);
go
insert into Faculties(Bilding,Name,DeanId)
values  ('1','Programing',2),
        ('2','Desian',1),
		('3','Economics',3),
		('4','Engineering',4);
		go

create table Heads
(
  Id int not null primary key identity (1,1),
  TeacherId int not null references Teachers(Id)
);
go
insert into Heads(TeacherId)
values  (2),
(4),
(3),
(1);
go

create table Departments
(
  Id int not null primary key identity (1,1),
  Bilding nvarchar(max) not null check(Bilding <>''),
  Name nvarchar(max) not null check(Name <>''),
  FacultId int not null references Faculties (Id),
  HeadId int not null references Heads(Id)
);
go
insert into Departments(Bilding,Name,FacultId,HeadId)
values  ('1','1d',2,1),
('2','2d',1,2),
('3','3d',3,4),
('4','4d',4,3);
go

create table Groups
(
    Id int not null primary key identity (1,1),
	Name nvarchar(max) not null check(Name <>''),
	Year date not null check(Year<GetDate()),
	DepartmentId int not null references Departments(Id)
);
alter table Groups
add Years int not null default(0)
go
insert into Groups(Name,Year,DepartmentId,Years)
values ('12B','2001-02-23',2,3),
('11A','2013-09-11',3,4),
('15F','2019-07-07',4,5),
('16G','2020-01-01',1,5);
go
create table GroupsLectures
(
   Id int not null primary key identity (1,1),
   GroupId int not null references Groups(Id),
   LectureId int not null references Lectures(Id)
);
go
insert into GroupsLectures(GroupId,LectureId)
values (5,1),
(7,3),
(6,2),
(4,4);
go

create table GroupsCurators
(
 Id int not null primary key identity (1,1),
 CuratorId int not null references Curators(Id),
 GroupId int not null references Groups(Id)
);
go
insert into GroupsCurators(CuratorId,GroupId)
values (1,5),
(2,4),
(3,6),
(4,7);
go
create table LectureRooms
(
  Id int not null primary key identity (1,1),
  Bilding nvarchar(max) not null check(Bilding <>''),
  Name nvarchar(max) not null check(Name <>''),
);
go

insert into LectureRooms(Bilding,Name)
values ('1','12G'),
('2','11H'),
('3','45Y'),
('4','15R');
go
create table Schedules 
(
  Id int not null primary key identity (1,1),
  Class int not null check(Class between 1 and 8),
  DayOfWeek int not null check(DayOfWeek between 1 and 7),
  Week int not null check (Week between 1 and 52),
  LectuerId int not null references Lectures(Id),
  LectureRoomId int not null references LectureRooms(Id)
);
go
insert into Schedules(Class,DayOfWeek,Week,LectuerId,LectureRoomId)
values (3,5,43,1,2),
(4,6,12,2,1),
(6,3,25,3,4),
(5,4,51,4,3);
go
--1. Вывести названия аудиторий, в которых читает лекции
--преподаватель “Edward Hopper”

select lr.Name
from LectureRooms as lr
where Exists (select l.Name
             from LectureRooms as l Join Schedules as s on s.LectureRoomId=l.Id
			                        Join Lectures as le on s.LectuerId=le.Id
									Join Teachers as t on le.TEacherId=t.Id
									where t.Name='Tom')

--2. Вывести фамилии ассистентов, читающих лекции в группе
--“F505”

select Name
from Assistents Join Teachers on Assistents.TeachersId=Teachers.Id
where Exists (select *
             from Assistents as a Join Teachers as t on a.TeachersId=t.Id
			                      Join Lectures as l on l.TEacherId=t.Id
								  Join GroupsLectures as gl on gl.LectureId=l.Id
								  join Groups as g on gl.GroupId=g.Id
								  where g.Name='11A')

--3. Вывести дисциплины, которые читает преподаватель “Alex
--Carmack” для групп 5-го курса.

select Name
from Subjects
where Exists (select *
             from Teachers as t Join Lectures as l on l.TEacherId=t.Id
			                    Join GroupsLectures as gl on gl.LectureId=l.Id 
								Join Groups as g on gl.GroupId=g.Id
								where t.Name='Jack' and g.Years=5)

--4. Вывести фамилии преподавателей, которые не читают
--лекции по понедельникам.
select Surname
from Teachers
where Exists (select *
             from Lectures as l Join Schedules as s on s.LectuerId=l.Id
			 where s.DayOfWeek<>1)

--5. Вывести названия аудиторий, с указанием их корпусов,
--в которых нет лекций в среду второй недели на третьей
--паре.
select l.Name, l.Bilding
from LectureRooms as l
where Exists (select * 
             from Schedules as s
			 where s.DayOfWeek<>2 and s.Class<>3)

--6. Вывести полные имена преподавателей факультета “Computer
--Science”, которые не курируют группы кафедры “Software
--Development”.select t.Name,t.Surnamefrom Teachers as twhere Exists (select *              from Curators as c Join GroupsCurators as gc on gc.CuratorId=c.Id			                     join Groups as g on gc.GroupId=g.Id								 join Departments as d on g.DepartmentId=d.Id								 join Faculties as f on d.FacultId=f.Id								 where f.Name<>'Programing' and d.Name<>'1d')--7. Вывести список номеров всех корпусов, которые имеются
--в таблицах факультетов, кафедр и аудиторий.select 'Faculties:', f.Bildingfrom Faculties as fUNION ALLselect 'Departments:', d.Bildingfrom Departments as dUNION Allselect 'Lecter rooms:', lr.Bilding from LectureRooms as lr--8. Вывести полные имена преподавателей в следующем порядке: деканы факультетов, заведующие кафедрами, преподаватели, кураторы, ассистенты.select t.Name,t.Surnamefrom Deans as d Join Teachers as t on d.TeachersId=t.IdUnion Allselect t.Name,t.Surnamefrom Teachers as t Join Heads as h on h.TeacherId=t.IdUnion Allselect  t.Name,t.Surnamefrom Teachers as tUnion Allselect t.Name,t.Surnamefrom Curators as c Join Teachers as t on c.TeachersId=t.IdUnion Allselect t.Name,t.Surnamefrom Assistents as a Join Teachers as t on a.TeachersId=t.Id--9. Вывести дни недели (без повторений), в которые имеются
--занятия в аудиториях “A311” и “A104” корпуса 6.

select s.DayOfWeek
from Schedules as s
where Exists (select lr.Name 
             from LectureRooms as lr 
			 where lr.Name='11H' or lr.Name='45Y' and lr.Bilding='2')